let plantas = [];
let tempoUltimaIrrigacao = 0;
let intervaloIrrigacao = 3000; // Tempo de irrigação em milissegundos
let pontos = 0;

function setup() {
  createCanvas(600, 400);
  noStroke();
  frameRate(30);
}

function draw() {
  background(220);
  
  // Desenha as plantas
  for (let planta of plantas) {
    planta.display();
    planta.update();
  }
  
  // Mostra o status do jogo
  fill(0);
  textSize(16);
  text('Pontos: ' + pontos, 10, 20);
  
  // Verifica o tempo de irrigação
  if (millis() - tempoUltimaIrrigacao > intervaloIrrigacao) {
    irrigarPlantas();
  }
}

function mousePressed() {
  // Adiciona uma nova planta quando o jogador clica
  let novaPlanta = new Planta(mouseX, mouseY);
  plantas.push(novaPlanta);
}

function irrigarPlantas() {
  // Irriga as plantas e aumenta o número de pontos
  for (let planta of plantas) {
    planta.irrigar();
  }
  tempoUltimaIrrigacao = millis();
  pontos++;
}

class Planta {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 10;
    this.saude = 100;
  }

  display() {
    // Desenha a planta
    fill(0, 255, 0);
    ellipse(this.x, this.y, this.tamanho, this.tamanho);
  }

  update() {
    // A saúde da planta diminui se não for irrigada
    this.saude -= 0.05;
    this.tamanho = map(this.saude, 0, 100, 10, 50);

    if (this.saude <= 0) {
      this.morrer();
    }
  }

  irrigar() {
    // Irriga a planta, restaurando sua saúde
    this.saude = min(100, this.saude + 20);
  }

  morrer() {
    // Remove a planta do array se sua saúde chegar a 0
    let index = plantas.indexOf(this);
    if (index > -1) {
      plantas.splice(index, 1);
    }
  }
}
